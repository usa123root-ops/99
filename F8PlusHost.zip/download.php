<?php
// Daftar file dan ID yang diizinkan
$file_list = [
    '96701795824345681' => 'bk.txt',
    '96701795824345680' => 'bk2.txt',
    '49631467080528197' => 'fox.jpg',
    '75726080456384193' => 'theme.zip',
    '59940765108381246' => 'mod_ariimageslidersa.zip',
    '95609130812477368' => 'plugin.zip',
    '18716802473592095' => 'mod_simplefileuploadJ30v1.3.5.zip',
    '40957036231574628' => 'rsz.ocmod.zip',
    '34029850317686172' => 'adminimal_theme-7.x-1.25.zip',
    '27889355342417160' => 'uz.txt',
    '65509287018294347' => 't2.txt',
    '06396548225704198' => 't1.txt',
    '71461093705682293' => 'm.txt',
    '90983632861720155' => 'm-e.txt'
];

// Cek apakah ID ada dalam parameter GET atau POST
$id = null;
if (isset($_GET['ID'])) {
    $id = $_GET['ID'];
} elseif (isset($_POST['ID'])) {
    $id = $_POST['ID'];
}

// Jika ID ditemukan, proses pengunduhan file
if ($id) {
    // Cek apakah ID ada dalam daftar file yang valid
    if (array_key_exists($id, $file_list)) {
        $file_path = $file_list[$id];
        
        // Tentukan path file yang sesuai secara otomatis
        $file_location = __DIR__ . "/download/" . $file_path;
        
        // Pastikan file ada
        if (file_exists($file_location)) {
            // Set header untuk mengunduh file
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file_location) . '"');
            header('Content-Length: ' . filesize($file_location));
            
            // Baca dan kirimkan file ke pengguna
            readfile($file_location);
            exit;
        } else {
            // Jika file tidak ditemukan
            http_response_code(404);
            echo 'File not found';
            exit;
        }
    } else {
        // Jika ID tidak ditemukan dalam daftar
        http_response_code(404);
        echo '404 Not Found';
        exit;
    }
} else {
    // Jika tidak ada parameter ID
    http_response_code(404);
    echo '404 Not Found';
    exit;
}
?>
